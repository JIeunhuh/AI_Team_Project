package edu.pnu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiProjectK3Application {

	public static void main(String[] args) {
		SpringApplication.run(AiProjectK3Application.class, args);
	}

}
